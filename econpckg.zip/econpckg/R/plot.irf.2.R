#'A plot.irf.2 function
#'
#' This function allows building the sophisticatred irf graphs as in Klishchuk O. (2018).
#' @param eta number of svarest or svecest model.
#' @param name.eta
#' @param model
#' @param main
#' @param v
#' @param w
#' @param mu
#' @param plot.kind
#' @param se
#' @param svar
#' @keywords irf, plot
#' @export
#' @examples eta=12;name.eta="Sovereign.Risk.Premium.h";model=12;v=-getp("sample.model.2","12")$K+2;w=2;mu=c(1:3)[];plot.kind="with area";se=TRUE;svar=TRUE
#' @examples plot.irf.2(eta,name.eta,model,main=NULL,v,w,mu,plot.kind,se=TRUE,svar=TRUE)
#' plot.irf.2()
#'
plot.irf.2<-
function(eta,name.eta,model,main=NULL,v=-getp("sample.model.2",model)$K+2,w=2,mu=c(1:3)[],plot.kind="with area",se=TRUE,svar=TRUE){
  # example: eta=12;name.eta="Sovereign.Risk.Premium.h";model=12;v=-getp("sample.model.2","12")$K+2;w=2;mu=c(1:3)[];plot.kind="with area";se=TRUE;svar=TRUE
  if(svar==TRUE){if(plot.kind=="with area"){
    if(!is.null(name.eta)){z=which(getp("ynames.",eta)==name.eta,arr.ind=TRUE)}else{z=1:length(getp("ynames.",eta))}
    if(eta==14){teta=14;teta1=13}else{teta=eta+1;teta1=teta};model=c("NBU",1:12,14)[teta];if(model=="NBU"){ylim=(range(exp(getp("svarchannel.2.",0)$svar.irf.AB[,]))*2.1)[1:2]}else{
      ylim=(range(exp(getp("svarchannel.2.",model)$svar.irf.AB[,]))*2.1);xlim=c(1,12)}
    if(is.null(main)){if(eta==14){main="змінної каналу 7.1"}else{if(eta==12){main="змінної каналу 4.1"}else {if(eta==11){main="змінної каналу 2.1"}else{main=paste("змінної каналу" ,readr::parse_number(model)+1)}}}}else{main=main}
    if(model=="NBU"){if(getp("sample.model.2",model)$K%%2==0){par(mfrow=c((round(getp("sample.model.2",model)$K+v)/2),2/w),
                                                                           mar=mar.,mai=mai.,oma=oma.,cex=cex.m,font.main=font.m.)}else{
                                                                             par(mfrow=c((round(getp("sample.model.2",model)$K+v)/2+0)+1,2/w),
                                                                                 mar=mar.,mai=mai.,oma=oma.,cex=cex.m,font.main=font.m.)};for(j in (1:getp("sample.model.2",model)$K)[z]){plot(exp(getp("svarchannel.2.",0)$svar.irf.AB[,1:3+(j-1)*3])[,2],ylim=range(exp(getp("svarchannel.2.",0)$svar.irf.AB[,1:3+(j-1)*3])),type="l",ylab=NAMES.0.U[j+1],xlab="місяці")+title(main=paste("Реакція змінної каналу", 1,"на шок",getp("NAMES.",0,".U")[1]),outer=TRUE)+grid(col=gray(.3,.8))
                                                                                   polygon(c(1:12,rev(1:12)),c(exp(getp("svarchannel.2.",0)$svar.irf.AB[,1:3+(j-1)*3])[,1],rev(exp(getp("svarchannel.2.",0)$svar.irf.AB[,1:3+(j-1)*3])[,2])),lty=2,col=heat.colors(1,.5),border="red",ylim=ylim)
                                                                                   polygon(c(1:12,rev(1:12)),c(exp(getp("svarchannel.2.",0)$svar.irf.AB[,1:3+(j-1)*3])[,2],rev(exp(getp("svarchannel.2.",0)$svar.irf.AB[,1:3+(j-1)*3])[,3])),lty=2,col=heat.colors(3,.5),border="red",ylim=ylim)}}else{
                                                                                     if(eta==14){if(getp("sample.model.2",model)$K%%2==0){par(mfrow=c((round(getp("sample.model.2",model)$K+v)/2+0),2/w),
                                                                                                                                                       mar=mar.,mai=mai.,oma=oma.,cex=cex.m,font.main=font.m.)}else{
                                                                                                                                                         par(mfrow=c((round(getp("sample.model.2",model)$K+v)/2+0)+1,2/w),
                                                                                                                                                             mar=mar.,mai=mai.,oma=oma.,cex=cex.m,font.main=font.m.)};for(j in c(1:getp("sample.model.2",model)$K)[z]){plot(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,2],type="l",lwd=2,col="black",ylim=range(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])),ylab=getp("NAMES.",(teta),".U")[j+1],xlab="місяці")+title(main=paste("Реакція", main,"на шок",getp("NAMES.",14,".U")[1]),outer=TRUE)+grid(col=gray(.3,.8))
                                                                                                                                                               polygon(c(1:12,rev(1:12)),c(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,1],rev(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,2])),lty=2,col=heat.colors(1,.5),border=NULL,ylim=ylim)
                                                                                                                                                               polygon(c(1:12,rev(1:12)),c(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,2],rev(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,3])),lty=2,col=heat.colors(3,.5),border=NULL,ylim=ylim)}
                                                                                     }else{
                                                                                       if(getp("sample.model.2",model)$K%%2==0){par(mfrow=c((round(getp("sample.model.2",model)$K+v)/2+0),2/w),
                                                                                                                                             mar=mar.,mai=mai.,oma=oma.,cex=cex.m,font.main=font.m.)}else{
                                                                                                                                               par(mfrow=c((round(getp("sample.model.2",model)$K+v)/2+0)+1,2/w),
                                                                                                                                                   mar=mar.,mai=mai.,oma=oma.,cex=cex.m,font.main=font.m.)};for(j in c(1:getp("sample.model.2",model)$K)[z]){plot(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,2],type="l",lwd=2,col="black",ylim=range(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])),ylab=getp("NAMES.",(teta1-1),".U")[j+1],xlab="місяці")+title(main=paste("Реакція", main,"на шок",getp("NAMES.",(teta1-1),".U")[1]),outer=TRUE)+grid(col=gray(.3,.8))
                                                                                                                                                     polygon(c(1:12,rev(1:12)),c(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,1],rev(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,2])),lty=2,col=heat.colors(1,.5),border=NULL,ylim=ylim)
                                                                                                                                                     polygon(c(1:12,rev(1:12)),c(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,2],rev(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,3])),lty=2,col=heat.colors(3,.5),border=NULL,ylim=ylim)}}}
  }else{

    {teta=eta+1;if(eta==14){teta=14;teta1=13}else{teta=eta+1;teta1=teta};
    if(!is.null(name.eta)){z=which(getp("ynames.",eta)==name.eta,arr.ind=TRUE)-1}else{z=2:length(getp("ynames.",eta))}
    if(is.null(main)){if(eta==14){main="змінної каналу 7.1"}else{if(eta==12){main="змінної каналу 4.1"}else {if(eta==11){main="змінної каналу 2.1"}else{main=paste("змінної каналу" ,readr::parse_number(model)+1)}}}}else{main=main}
    mar.=c(.25,.3,5,.5);mai.=0.1*c(2.5*.1/.1,3.5*.2/.1,
                                   3.1*.1/.1,2.3*.2/.1);oma.=.2*c(.19,.7,4.9,.8);cex.m=.7;font.m.=4
    model=c("NBU",1:12,14)[teta];if(model=="NBU"){if(getp("sample.model.2",model)$K%%2==0){par(mfrow=c((round((getp("sample.model.2",model)$K-1)/2)+0),2),
                                                                                                        mar=mar.,mai=mai.,oma=oma.,cex=cex.m,font.main=4)}else{
                                                                                                          par(mfrow=c(round((getp("sample.model.2",model)$K-1)/2),2),
                                                                                                              mar=mar.,oma=oma.,mai=mai.,cex=cex.m,font.main=font.m.)};for(j in c(2:getp("sample.model.2",model)$K)[z]){plot(exp(getp("svarchannel.2.",0)$svar.irf.AB[,1:3+(j-1)*3])[,2],type="l",ylab=getp("NAMES.",0,".U")[j+1],ylim=range(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[mu]),xlab="місяці")+title(main=paste("Реакція змінної каналу", 0+1,"на шок",getp("NAMES.",0,".U")[1]),outer=TRUE)+grid(col=gray(.3,.8))
                                                                                                                if(se==TRUE){
                                                                                                                  lines(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,1],lty=2,col=gray(.47,.9))
                                                                                                                  lines(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,3],lty=2,col=gray(.57,.9))
                                                                                                                }}}else{if(model==14){
                                                                                                                  par(mfrow=c(round((getp("sample.model.2",model)$K-K+2)/2),2/w),
                                                                                                                      mar=mar.,oma=oma.,mai=mai.,cex=cex.m,font.main=font.m.);for(j in c(2:getp("sample.model.2",model)$K)[z]){plot(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,2],type="l",ylab=getp("NAMES.",model,".U")[j+1],ylim=range(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3][mu])),xlab="місяці")+title(main=paste("Реакція", main,"на шок",getp("NAMES.",14,".U")[1]),outer=TRUE)+grid(col=gray(.3,.8))
                                                                                                                        if(se==TRUE){
                                                                                                                          lines(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,1],lty=2,col=gray(.47,.9))
                                                                                                                          lines(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,3],lty=2,col=gray(.57,.9))}}
                                                                                                                }else{
                                                                                                                  par(mfrow=c(round((getp("sample.model.2",model)$K-K+2)/2),2/w),
                                                                                                                      mar=mar.,oma=oma.,mai=mai.,cex=cex.m,font.main=font.m.);for(j in c(2:getp("sample.model.2",model)$K)[z]){plot(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,2],type="l",ylab=getp("NAMES.",model,".U")[j+1],ylim=range(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3][mu])),xlab="місяці")+title(main=paste("Реакція", main,"на шок",getp("NAMES.",model,".U")[1]),outer=TRUE)+grid(col=gray(.3,.8))
                                                                                                                        if(se==TRUE){
                                                                                                                          lines(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,1],lty=2,col=gray(.47,.9))
                                                                                                                          lines(exp(getp("svarchannel.2.",model)$svar.irf.AB[,1:3+(j-1)*3])[,3],lty=2,col=gray(.57,.9))}
                                                                                                                      }}}
    }

  }
  }else{
    eta;if(!is.null(name.eta)){z=which(getp("ynames.",eta)==name.eta,arr.ind=TRUE)}else{z=1:length(getp("ynames.",eta))}
    teta=eta+1;if(eta==14){teta=14};model=c("NBU",1:12,14)[teta];if(model=="NBU"){ylim=(range(exp(getp("svarchannel.2.",0)$svar.irf.AB[,]))*2.1)[1:2]}else{
      ylim=(range(exp(getp("svec.channel",eta)$svec$svec.irf.AB[,]))*2.1);xlim=c(1,12)}
    if(is.null(main)){if(eta==14){main="змінної каналу 7.1"}else{if(eta==12){main="змінної каналу 4.1"}else {if(eta==11){main="змінної каналу 2.1"}else{main=paste("змінної каналу" ,readr::parse_number(model)+1)}}}}else{main=main}
    if(model=="NBU"){if(getp("sample.model.2",model)$K%%2==0){par(mfrow=c((round(getp("sample.model.2",model)$K+v)/2+0),2/w),
                                                                           mar=mar.,mai=mai.,oma=oma.,cex=cex.m,font.main=font.m.)}else{
                                                                             par(mfrow=c((round(getp("sample.model.2",model)$K+v)/2+0)+1,2/w),
                                                                                 mar=mar.,mai=mai.,oma=oma.,cex=cex.m,font.main=font.m.)};for(j in c(1:getp("sample.model.2",model)$K)[z]){plot(exp(getp("svec.channel",eta)$svec$svec.irf.AB[,1:3+(j-1)*3])[,2],ylim=range(exp(getp("svec.channel",0)$svec$svec.irf.AB[,1:3+(j-1)*3])),type="l",ylab=NAMES.0.U[j+1],xlab="місяці")+title(main=paste("Реакція змінної каналу", 1,"на шок",getp("NAMES.",0,".U")[1]),outer=TRUE)+grid(col=gray(.3,.8))
                                                                                   polygon(c(1:12,rev(1:12)),c(exp(getp("svec.channel",0)$svec$svec.irf.AB[,1:3+(j-1)*3])[,1],rev(exp(getp("svec.channel",eta)$svec$svec.irf.AB[,1:3+(j-1)*3])[,2])),lty=2,col=heat.colors(1,.5),border="red",ylim=ylim)
                                                                                   polygon(c(1:12,rev(1:12)),c(exp(getp("svec.channel",0)$svec$svec.irf.AB[,1:3+(j-1)*3])[,2],rev(exp(getp("svec.channel",eta)$svec$svec.irf.AB[,1:3+(j-1)*3])[,3])),lty=2,col=heat.colors(3,.5),border="red",ylim=ylim)}}else{
                                                                                     if(model==14){if(getp("sample.model.2",model)$K%%2==0){par(mfrow=c((round(getp("sample.model.2",model)$K+v)/2+0),2/w),
                                                                                                                                                         mar=mar.,mai=mai.,oma=oma.,cex=cex.m,font.main=font.m.)}else{
                                                                                                                                                           par(mfrow=c((round(getp("sample.model.2",model)$K+v)/2+0)+1,2/w),
                                                                                                                                                               mar=mar.,mai=mai.,oma=oma.,cex=cex.m,font.main=font.m.)};for(j in c(1:getp("sample.model.2",model)$K)[z]){plot(exp(getp("svec.channel",model)$svec$svec.irf.AB[,1:3+(j-1)*3])[,2],type="l",lwd=2,col="black",ylim=range(exp(getp("svec.channel",model)$svec$svec.irf.AB[,1:3+(j-1)*3])),ylab=getp("NAMES.",14,".U")[j+1],xlab="місяці")+title(main=paste("Реакція", main,"на шок",getp("NAMES.",14,".U")[1]),outer=TRUE)+grid(col=gray(.3,.8))
                                                                                                                                                                 polygon(c(1:12,rev(1:12)),c(exp(getp("svec.channel",eta)$svec$svec.irf.AB[,1:3+(j-1)*3])[,1],rev(exp(getp("svec.channel",model)$svec$svec.irf.AB[,1:3+(j-1)*3])[,2])),lty=2,col=heat.colors(1,.5),border=NULL,ylim=ylim)
                                                                                                                                                                 polygon(c(1:12,rev(1:12)),c(exp(getp("svec.channel",eta)$svec$svec.irf.AB[,1:3+(j-1)*3])[,2],rev(exp(getp("svec.channel",model)$svec$svec.irf.AB[,1:3+(j-1)*3])[,3])),lty=2,col=heat.colors(3,.5),border=NULL,ylim=ylim)}
                                                                                     }else{
                                                                                       if(getp("sample.model.2",model)$K%%2==0){par(mfrow=c((round(getp("sample.model.2",model)$K+v)/2+0),2/w),
                                                                                                                                             mar=mar.,mai=mai.,oma=oma.,cex=cex.m,font.main=font.m.)}else{
                                                                                                                                               par(mfrow=c((round(getp("sample.model.2",model)$K+v)/2+0)+1,2/w),
                                                                                                                                                   mar=mar.,mai=mai.,oma=oma.,cex=cex.m,font.main=font.m.)};for(j in c(1:getp("sample.model.2",model)$K)[z]){plot(exp(getp("svec.channel",model)$svec$svec.irf.AB[,1:3+(j-1)*3])[,2],type="l",lwd=2,col="black",ylim=range(exp(getp("svec.channel",model)$svec$svec.irf.AB[,1:3+(j-1)*3])),ylab=getp("NAMES.",model,".U")[j+1],xlab="місяці")+title(main=paste("Реакція", main,"на шок",getp("NAMES.",(teta-1),".U")[1]),outer=TRUE)+grid(col=gray(.3,.8))
                                                                                                                                                     polygon(c(1:12,rev(1:12)),c(exp(getp("svec.channel",eta)$svec$svec.irf.AB[,1:3+(j-1)*3])[,1],rev(exp(getp("svec.channel",model)$svec$svec.irf.AB[,1:3+(j-1)*3])[,2])),lty=2,col=heat.colors(1,.5),border=NULL,ylim=ylim)
                                                                                                                                                     polygon(c(1:12,rev(1:12)),c(exp(getp("svec.channel",eta)$svec$svec.irf.AB[,1:3+(j-1)*3])[,2],rev(exp(getp("svec.channel",model)$svec$svec.irf.AB[,1:3+(j-1)*3])[,3])),lty=2,col=heat.colors(3,.5),border=NULL,ylim=ylim)}}}
  }
}
